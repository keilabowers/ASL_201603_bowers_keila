@extends('layouts.app')
@extends('home')

@section('sidebar')
@parent
<div class="row">
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="" alt="">
      <div class="caption">
        <h3> wha;t;ljs</h3>
        <p>...</p>
      </div>
    </div>
  </div>
</div>
@endsection

