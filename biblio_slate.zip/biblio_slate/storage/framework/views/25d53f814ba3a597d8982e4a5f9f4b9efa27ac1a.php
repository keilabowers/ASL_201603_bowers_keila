<?php $__env->startSection('readinglog'); ?>
<?php foreach($userbooks as $userbook): ?>
	<div>
		<ul>
			<a href="/readinglog/<?php echo e($userbook->id); ?>"><li><?php echo e($userbook->book->title); ?><?php echo e($userbook->book->authorname); ?><?php echo e($userbook->book->isbn); ?><?php echo e($userbook->read); ?><?php echo e($userbook->wishlist); ?><li></a>
		</ul>
	</div>
<?php endforeach; ?> 
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>