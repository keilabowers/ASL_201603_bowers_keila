<?php $__env->startSection('bookshelf'); ?>
<?php foreach($userbooks as $userbook): ?>
	<div>
		<ul>
			<a href="/readinglog/<?php echo e($userbook->id); ?>"><li><?php echo e($userbook->book->title); ?><?php echo e($userbook->book->authorname); ?><?php echo e($userbook->book->isbn); ?><?php echo e($userbook->owned); ?><li></a>
		</ul>
	</div>
<?php endforeach; ?>

	<h2>User Loans</h2>
<?php foreach($userloans as $userloan): ?>
	<div>
		<ul>
			<a href="/bookshelf/<?php echo e($userloan->id); ?>"><li><?php echo e($userloan->title); ?><?php echo e($userloan->name); ?><li></a>
		</ul>
	</div>
<?php endforeach; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>